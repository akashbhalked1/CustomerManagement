assignLogPoint = function assignLogPoint() { // eslint-disable-line no-undef

	var flowName = context.flow;
	context.setVariable("loggingFlow", flowName);

};